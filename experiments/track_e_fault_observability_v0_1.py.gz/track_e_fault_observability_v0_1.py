#!/usr/bin/env python3
"""MindMap Track E v0.1: equal-information fault-observability audit.

This is a fixed synthetic mechanism test, not an end-to-end LLM benchmark.
It compares validator tiers. G-Complete/T-Canonical and G-Envelope/T-Envelope
share the same invariant specification, so equality is the expected null.
"""
from __future__ import annotations

import argparse
import copy
import csv
import hashlib
import json
import platform
import statistics
import time
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

KNOWN_TYPES = {
    "branch", "instance", "lineage", "evidence", "transfer", "adoption",
    "snapshot", "restore", "policy", "justification", "envelope", "cache",
}

REQUIRED = {
    "branch": {"id", "type", "parent", "fork_valid", "system_time"},
    "instance": {"id", "type", "principal", "created_system", "system_time"},
    "lineage": {"id", "type", "kind", "source", "destination", "authorized", "system_time"},
    "evidence": {"id", "type", "proposition", "truth", "about_branch", "valid_time", "system_time", "witnesses", "policy", "allowed_requesters", "origin_family"},
    "transfer": {"id", "type", "evidence", "source", "destination", "kind", "authorized", "valid_time", "system_time"},
    "adoption": {"id", "type", "evidence", "destination", "stance", "valid_time", "system_time"},
    "snapshot": {"id", "type", "source", "cutoff_system", "entries", "system_time"},
    "restore": {"id", "type", "snapshot", "destination", "valid_time", "system_time"},
    "policy": {"id", "type", "evidence", "operation", "requester", "valid_time", "system_time"},
    "justification": {"id", "type", "claim", "sources", "requires_independent", "system_time"},
    "envelope": {"id", "type", "expected_ids", "hashes", "system_time"},
    "cache": {"id", "type", "key", "value", "ledger_head_hash", "system_time"},
}

ENUMS = {
    ("lineage", "kind"): {"operational_replica", "identity_fork", "restore"},
    ("transfer", "kind"): {"attributed_report", "evidence_copy", "authorized_state_replication"},
    ("adoption", "stance"): {"believe", "disbelieve", "doubt", "suspend"},
    ("policy", "operation"): {"grant", "revoke", "delete", "grant_public", "declassify"},
}


@dataclass(frozen=True)
class Alert:
    rule: str
    event_id: str | None
    stage: str
    detail: str = ""


@dataclass(frozen=True)
class Query:
    kind: str
    params: dict[str, Any]


@dataclass
class FaultCase:
    case_id: str
    fault_class: str
    detectable_level: str  # local | semantic | envelope | unobservable | clean
    clean_events: list[dict[str, Any]]
    faulty_events: list[dict[str, Any]]
    query: Query
    expected: Any
    mutated_ids: tuple[str, ...] = ()
    notes: str = ""


@dataclass(frozen=True)
class SystemSpec:
    name: str
    level: str  # raw | local | semantic | envelope
    representation: str


SYSTEMS = (
    SystemSpec("G-Raw", "raw", "generic"),
    SystemSpec("T-Local", "local", "typed"),
    SystemSpec("G-Complete", "semantic", "generic"),
    SystemSpec("T-Canonical", "semantic", "typed"),
    SystemSpec("G-Envelope", "envelope", "generic"),
    SystemSpec("T-Envelope", "envelope", "typed"),
)


def canonical_event(event: dict[str, Any]) -> bytes:
    body = {k: v for k, v in event.items() if not k.startswith("_")}
    return json.dumps(body, sort_keys=True, separators=(",", ":")).encode()


def event_hash(event: dict[str, Any]) -> str:
    return hashlib.sha256(canonical_event(event)).hexdigest()


def ledger_head_hash(events: Iterable[dict[str, Any]]) -> str:
    digest = hashlib.sha256()
    ordered = sorted(
        (e for e in events if e.get("type") not in {"envelope", "cache"}),
        key=lambda e: (e.get("system_time", 10**12), e.get("id", "")),
    )
    for event in ordered:
        digest.update(event_hash(event).encode())
    return digest.hexdigest()


def structural_alerts(events: list[dict[str, Any]]) -> list[Alert]:
    alerts: list[Alert] = []
    seen: dict[str, str] = {}
    for event in events:
        event_id = event.get("id")
        if not isinstance(event_id, str) or not event_id:
            alerts.append(Alert("missing_event_id", None, "ingest"))
            continue
        digest = event_hash(event)
        if event_id in seen and seen[event_id] != digest:
            alerts.append(Alert("duplicate_conflicting_id", event_id, "ingest"))
        else:
            seen[event_id] = digest
    return alerts


def local_alerts(events: list[dict[str, Any]]) -> list[Alert]:
    alerts = structural_alerts(events)
    branch_ids = {e.get("id") for e in events if e.get("type") == "branch"}
    instance_ids = {e.get("id") for e in events if e.get("type") == "instance"}
    evidence_ids = {e.get("id") for e in events if e.get("type") == "evidence"}
    snapshot_ids = {e.get("id") for e in events if e.get("type") == "snapshot"}

    for event in events:
        event_id, event_type = event.get("id"), event.get("type")
        if event_type not in KNOWN_TYPES:
            alerts.append(Alert("unknown_event_type", event_id, "insert", repr(event_type)))
            continue
        missing = sorted(REQUIRED[event_type] - set(event))
        if missing:
            alerts.append(Alert("missing_required_field", event_id, "insert", ",".join(missing)))
            continue
        if not isinstance(event.get("system_time"), int) or event["system_time"] < 0:
            alerts.append(Alert("invalid_system_time", event_id, "insert"))
        if "valid_time" in event and (
            not isinstance(event.get("valid_time"), int) or event["valid_time"] < 0
        ):
            alerts.append(Alert("invalid_valid_time", event_id, "insert"))
        for field in ("kind", "stance", "operation"):
            allowed = ENUMS.get((event_type, field))
            if allowed is not None and event.get(field) not in allowed:
                alerts.append(Alert("invalid_enum", event_id, "insert", f"{field}={event.get(field)!r}"))

        def require_ref(value: Any, universe: set[Any], rule: str) -> None:
            if value not in universe:
                alerts.append(Alert(rule, event_id, "insert", str(value)))

        if event_type == "branch" and event.get("parent") is not None:
            require_ref(event.get("parent"), branch_ids, "unknown_branch_reference")
        elif event_type == "lineage":
            require_ref(event.get("source"), instance_ids, "unknown_instance_reference")
            require_ref(event.get("destination"), instance_ids, "unknown_instance_reference")
        elif event_type == "evidence":
            require_ref(event.get("about_branch"), branch_ids, "unknown_branch_reference")
        elif event_type == "transfer":
            require_ref(event.get("evidence"), evidence_ids, "unknown_evidence_reference")
            require_ref(event.get("source"), instance_ids, "unknown_instance_reference")
            require_ref(event.get("destination"), instance_ids, "unknown_instance_reference")
        elif event_type == "adoption":
            require_ref(event.get("evidence"), evidence_ids, "unknown_evidence_reference")
            require_ref(event.get("destination"), instance_ids, "unknown_instance_reference")
        elif event_type == "snapshot":
            require_ref(event.get("source"), instance_ids, "unknown_instance_reference")
            for source_id in event.get("entries", []):
                require_ref(source_id, evidence_ids, "unknown_evidence_reference")
        elif event_type == "restore":
            require_ref(event.get("snapshot"), snapshot_ids, "unknown_snapshot_reference")
            require_ref(event.get("destination"), instance_ids, "unknown_instance_reference")
        elif event_type == "policy":
            require_ref(event.get("evidence"), evidence_ids, "unknown_evidence_reference")
        elif event_type == "justification":
            for source_id in event.get("sources", []):
                require_ref(source_id, evidence_ids, "unknown_evidence_reference")
    return alerts


def semantic_alerts(events: list[dict[str, Any]]) -> list[Alert]:
    alerts = local_alerts(events)
    valid_rows = [e for e in events if e.get("type") in KNOWN_TYPES and not (REQUIRED[e["type"]] - set(e))]
    rows = sorted(valid_rows, key=lambda e: (e.get("system_time", 10**12), e.get("id", "")))
    instances: dict[str, dict[str, Any]] = {}
    evidence: dict[str, dict[str, Any]] = {}
    lineage: list[dict[str, Any]] = []
    exposure_times: dict[tuple[str, str], list[int]] = defaultdict(list)
    policy_ops: dict[tuple[str, str | None, int, int], list[dict[str, Any]]] = defaultdict(list)

    for event in rows:
        event_id, event_type, system_time = event["id"], event["type"], event["system_time"]
        if event_type == "instance":
            instances[event_id] = event
        elif event_type == "lineage":
            if not event["authorized"]:
                alerts.append(Alert("unauthorized_lineage", event_id, "commit"))
            source, destination = event["source"], event["destination"]
            if source in instances and destination in instances:
                same_principal = instances[source]["principal"] == instances[destination]["principal"]
                if event["kind"] == "operational_replica" and not same_principal:
                    alerts.append(Alert("operational_replica_principal_mismatch", event_id, "commit"))
                if event["kind"] == "identity_fork" and same_principal:
                    alerts.append(Alert("identity_fork_requires_new_principal", event_id, "commit"))
            lineage.append(event)
        elif event_type == "evidence":
            evidence[event_id] = event
            for witness in event["witnesses"]:
                if witness not in instances:
                    alerts.append(Alert("unknown_witness", event_id, "commit", witness))
                else:
                    exposure_times[(witness, event_id)].append(system_time)
            parent_id = event.get("derived_from")
            if parent_id and parent_id in evidence:
                parent = evidence[parent_id]
                if parent.get("policy") == "private" and event.get("policy") == "public":
                    declassified = any(
                        p.get("type") == "policy"
                        and p.get("evidence") == parent_id
                        and p.get("operation") in {"grant_public", "declassify"}
                        and p.get("system_time", 10**12) <= system_time
                        for p in rows
                    )
                    if not declassified:
                        alerts.append(Alert("policy_laundering", event_id, "commit", parent_id))
                if event.get("origin_family") != parent.get("origin_family"):
                    alerts.append(Alert("origin_family_laundering", event_id, "commit", parent_id))
        elif event_type == "transfer":
            source, destination, evidence_id = event["source"], event["destination"], event["evidence"]
            invalid = False
            if not event["authorized"]:
                alerts.append(Alert("unauthorized_transfer", event_id, "commit")); invalid = True
            if not any(t <= system_time for t in exposure_times.get((source, evidence_id), [])):
                alerts.append(Alert("source_not_exposed", event_id, "commit")); invalid = True
            if event["kind"] == "authorized_state_replication":
                same_principal = (
                    source in instances and destination in instances
                    and instances[source]["principal"] == instances[destination]["principal"]
                )
                edge_ok = any(
                    edge["source"] == source and edge["destination"] == destination
                    and edge["kind"] == "operational_replica" and edge["authorized"]
                    and edge["system_time"] <= system_time
                    for edge in lineage
                )
                if not (same_principal and edge_ok and event["authorized"]):
                    alerts.append(Alert("invalid_first_person_replication", event_id, "commit")); invalid = True
            if not invalid:
                exposure_times[(destination, evidence_id)].append(system_time)
        elif event_type == "adoption":
            key = (event["destination"], event["evidence"])
            if not any(t <= system_time for t in exposure_times.get(key, [])):
                alerts.append(Alert("adoption_without_exposure", event_id, "commit"))
        elif event_type == "snapshot":
            cutoff = event["cutoff_system"]
            for evidence_id in event["entries"]:
                source_event = evidence.get(evidence_id)
                if source_event and source_event["system_time"] > cutoff:
                    alerts.append(Alert("snapshot_post_cutoff_entry", event_id, "commit", evidence_id))
                if not any(t <= cutoff for t in exposure_times.get((event["source"], evidence_id), [])):
                    alerts.append(Alert("snapshot_source_lacks_entry", event_id, "commit", evidence_id))
        elif event_type == "policy":
            key = (event["evidence"], event.get("requester"), event["valid_time"], event["system_time"])
            policy_ops[key].append(event)
        elif event_type == "justification" and event["requires_independent"]:
            families = [evidence[s]["origin_family"] for s in event["sources"] if s in evidence]
            if len(families) != len(set(families)):
                alerts.append(Alert("non_independent_support", event_id, "commit"))

    for grouped in policy_ops.values():
        operations = {event["operation"] for event in grouped}
        if len(operations) > 1:
            for event in grouped:
                alerts.append(Alert("ambiguous_same_time_policy", event["id"], "commit", ",".join(sorted(operations))))
    return alerts


def envelope_alerts(events: list[dict[str, Any]]) -> list[Alert]:
    alerts = semantic_alerts(events)
    by_id = {e.get("id"): e for e in events if isinstance(e.get("id"), str)}
    for envelope in (e for e in events if e.get("type") == "envelope"):
        for expected_id in envelope.get("expected_ids", []):
            if expected_id not in by_id:
                alerts.append(Alert("envelope_missing_event", expected_id, "commit", envelope["id"]))
            else:
                expected_hash = envelope.get("hashes", {}).get(expected_id)
                if expected_hash and event_hash(by_id[expected_id]) != expected_hash:
                    alerts.append(Alert("envelope_hash_mismatch", expected_id, "commit", envelope["id"]))
    current_head = ledger_head_hash(events)
    for cache in (e for e in events if e.get("type") == "cache"):
        if cache.get("ledger_head_hash") != current_head:
            alerts.append(Alert("projection_head_mismatch", cache.get("id"), "projection"))
    return alerts


def alerts_for_system(events: list[dict[str, Any]], system: SystemSpec) -> list[Alert]:
    return {
        "raw": structural_alerts,
        "local": local_alerts,
        "semantic": semantic_alerts,
        "envelope": envelope_alerts,
    }[system.level](events)


def branch_visible(branches: dict[str, dict[str, Any]], source: str, target: str, valid_time: int) -> bool:
    cursor = target
    while True:
        if cursor == source:
            return True
        row = branches.get(cursor)
        if row is None or row.get("parent") is None:
            return False
        if row.get("fork_valid") is not None and valid_time > row["fork_valid"]:
            return False
        cursor = row["parent"]


def exposure_history(events: list[dict[str, Any]], instance: str, evidence_id: str, system_time: int) -> list[tuple[int, str, str | None, bool]]:
    history: list[tuple[int, str, str | None, bool]] = []
    evidence = next((e for e in events if e.get("type") == "evidence" and e.get("id") == evidence_id), None)
    if evidence and instance in evidence.get("witnesses", []) and evidence.get("system_time", 10**12) <= system_time:
        history.append((evidence["system_time"], "direct_observation", None, True))
    for transfer in events:
        if transfer.get("type") == "transfer" and transfer.get("destination") == instance and transfer.get("evidence") == evidence_id and transfer.get("system_time", 10**12) <= system_time:
            history.append((transfer["system_time"], transfer.get("kind", "unknown"), transfer.get("source"), bool(transfer.get("authorized"))))
    snapshots = {e["id"]: e for e in events if e.get("type") == "snapshot" and "id" in e}
    for restore in events:
        if restore.get("type") == "restore" and restore.get("destination") == instance and restore.get("system_time", 10**12) <= system_time:
            snapshot = snapshots.get(restore.get("snapshot"))
            if snapshot and evidence_id in snapshot.get("entries", []):
                history.append((restore["system_time"], "restored_snapshot", snapshot.get("source"), True))
    return sorted(history)


def policy_allows(events: list[dict[str, Any]], evidence_id: str, requester: str, system_time: int) -> bool:
    evidence = next(e for e in events if e.get("type") == "evidence" and e.get("id") == evidence_id)
    active = True
    public = evidence.get("policy", "public") == "public"
    allowed = set(evidence.get("allowed_requesters", []))
    denied: set[str] = set()
    policies = sorted(
        (e for e in events if e.get("type") == "policy" and e.get("evidence") == evidence_id and e.get("system_time", 10**12) <= system_time),
        key=lambda e: (e.get("valid_time", 0), e.get("system_time", 0), e.get("id", "")),
    )
    for event in policies:
        operation, target = event["operation"], event.get("requester")
        if operation == "delete":
            active = False
        elif operation in {"grant_public", "declassify"}:
            active, public, allowed, denied = True, True, set(), set()
        elif operation == "grant" and target:
            active = True
            if public:
                denied.discard(target)
            else:
                allowed.add(target)
        elif operation == "revoke" and target:
            if public:
                denied.add(target)
            else:
                allowed.discard(target)
    return active and ((public and requester not in denied) or (not public and requester in allowed))


def resolve_query(events: list[dict[str, Any]], query: Query) -> Any:
    rows = sorted(events, key=lambda e: (e.get("system_time", 10**12), e.get("id", "")))
    params = query.params
    if query.kind == "WORLD":
        branches = {e["id"]: e for e in rows if e.get("type") == "branch" and "id" in e}
        candidates = [
            e for e in rows
            if e.get("type") == "evidence"
            and e.get("proposition") == params["proposition"]
            and e.get("valid_time", 10**12) <= params["valid_time"]
            and e.get("system_time", 10**12) <= params["system_time"]
            and branch_visible(branches, e.get("about_branch"), params["branch"], e.get("valid_time"))
        ]
        return candidates[-1]["truth"] if candidates else None
    if query.kind == "EVER_EXPOSED":
        return bool(exposure_history(events, params["instance"], params["evidence"], params["system_time"]))
    if query.kind == "ATTRIBUTION":
        history = exposure_history(events, params["instance"], params["evidence"], params["system_time"])
        if any(kind == "direct_observation" for _, kind, _, _ in history):
            return "direct_observation"
        if not history:
            return "none"
        _, kind, _, authorized = history[-1]
        return {
            "attributed_report": "attributed_report",
            "evidence_copy": "copied_artifact",
            "authorized_state_replication": "first_person_replication" if authorized else "copied_artifact",
            "restored_snapshot": "restored_snapshot",
        }.get(kind, "unknown")
    if query.kind == "ATTITUDE":
        adoptions = [
            e for e in rows if e.get("type") == "adoption"
            and e.get("destination") == params["instance"]
            and e.get("evidence") == params["evidence"]
            and e.get("system_time", 10**12) <= params["system_time"]
        ]
        return adoptions[-1]["stance"] if adoptions else "unknown"
    if query.kind == "DISCLOSE":
        justifications = [e for e in rows if e.get("type") == "justification" and e.get("claim") == params["claim"]]
        return any(all(policy_allows(events, source, params["requester"], params["system_time"]) for source in j["sources"]) for j in justifications)
    if query.kind == "CACHE":
        caches = [e for e in rows if e.get("type") == "cache" and e.get("key") == params["key"] and e.get("system_time", 10**12) <= params["system_time"]]
        return caches[-1]["value"] if caches else None
    raise ValueError(query.kind)


def base_events() -> list[dict[str, Any]]:
    return [
        {"id": "B0", "type": "branch", "parent": None, "fork_valid": None, "system_time": 1},
        {"id": "B1", "type": "branch", "parent": "B0", "fork_valid": 10, "system_time": 2},
        {"id": "I1", "type": "instance", "principal": "P1", "created_system": 1, "system_time": 1},
        {"id": "I2", "type": "instance", "principal": "P1", "created_system": 1, "system_time": 1},
        {"id": "I3", "type": "instance", "principal": "P2", "created_system": 1, "system_time": 1},
        {"id": "L12", "type": "lineage", "kind": "operational_replica", "source": "I1", "destination": "I2", "authorized": True, "system_time": 2},
        {"id": "L13", "type": "lineage", "kind": "identity_fork", "source": "I1", "destination": "I3", "authorized": True, "system_time": 2},
    ]


def evidence(eid: str = "E1", *, proposition: str = "x=true", truth: bool = True, about: str = "B0", valid: int = 5, system: int = 5, witnesses: tuple[str, ...] = ("I1",), policy: str = "public", allowed: tuple[str, ...] = (), origin: str | None = None, derived_from: str | None = None) -> dict[str, Any]:
    row = {"id": eid, "type": "evidence", "proposition": proposition, "truth": truth, "about_branch": about, "valid_time": valid, "system_time": system, "witnesses": list(witnesses), "policy": policy, "allowed_requesters": list(allowed), "origin_family": origin or eid}
    if derived_from:
        row["derived_from"] = derived_from
    return row


def transfer(tid: str = "T1", *, evidence_id: str = "E1", source: str = "I1", destination: str = "I2", kind: str = "attributed_report", authorized: bool = True, valid: int = 6, system: int = 6) -> dict[str, Any]:
    return {"id": tid, "type": "transfer", "evidence": evidence_id, "source": source, "destination": destination, "kind": kind, "authorized": authorized, "valid_time": valid, "system_time": system}


def adoption(aid: str = "A1", *, evidence_id: str = "E1", destination: str = "I2", stance: str = "believe", valid: int = 7, system: int = 7) -> dict[str, Any]:
    return {"id": aid, "type": "adoption", "evidence": evidence_id, "destination": destination, "stance": stance, "valid_time": valid, "system_time": system}


def policy(pid: str = "P1", *, evidence_id: str = "E1", operation: str = "revoke", requester: str = "U", valid: int = 10, system: int = 10) -> dict[str, Any]:
    return {"id": pid, "type": "policy", "evidence": evidence_id, "operation": operation, "requester": requester, "valid_time": valid, "system_time": system}


def justification(jid: str = "J1", *, claim: str = "C1", sources: tuple[str, ...] = ("E1",), independent: bool = False, system: int = 8) -> dict[str, Any]:
    return {"id": jid, "type": "justification", "claim": claim, "sources": list(sources), "requires_independent": independent, "system_time": system}


def add_envelope(events: list[dict[str, Any]], expected_ids: list[str], envelope_id: str = "ENV") -> list[dict[str, Any]]:
    result = copy.deepcopy(events)
    by_id = {e["id"]: e for e in result}
    result.append({"id": envelope_id, "type": "envelope", "expected_ids": expected_ids, "hashes": {event_id: event_hash(by_id[event_id]) for event_id in expected_ids}, "system_time": max(e["system_time"] for e in result) + 1})
    return result


def make_cases() -> list[FaultCase]:
    cases: list[FaultCase] = []

    clean = base_events() + [evidence(), transfer()]
    faulty = copy.deepcopy(clean); next(e for e in faulty if e["id"] == "T1").pop("destination")
    cases.append(FaultCase("F01_missing_required_field", "local_schema", "local", clean, faulty, Query("EVER_EXPOSED", {"instance": "I2", "evidence": "E1", "system_time": 20}), True, ("T1",)))

    clean = base_events() + [evidence(), transfer()]
    faulty = copy.deepcopy(clean); next(e for e in faulty if e["id"] == "T1")["kind"] = "telepathic_merge"
    cases.append(FaultCase("F02_invalid_enum", "local_schema", "local", clean, faulty, Query("ATTRIBUTION", {"instance": "I2", "evidence": "E1", "system_time": 20}), "attributed_report", ("T1",)))

    clean = base_events() + [evidence(), transfer()]
    faulty = copy.deepcopy(clean); next(e for e in faulty if e["id"] == "T1")["evidence"] = "E404"
    cases.append(FaultCase("F03_unknown_reference", "referential", "local", clean, faulty, Query("EVER_EXPOSED", {"instance": "I2", "evidence": "E1", "system_time": 20}), True, ("T1",)))

    clean = base_events() + [evidence(truth=True)]
    faulty = copy.deepcopy(clean) + [evidence(eid="E1", truth=False, system=6)]
    cases.append(FaultCase("F04_duplicate_conflicting_id", "structural", "local", clean, faulty, Query("WORLD", {"proposition": "x=true", "branch": "B0", "valid_time": 20, "system_time": 20}), True, ("E1",)))

    clean = base_events() + [evidence()]
    faulty = copy.deepcopy(clean) + [transfer(tid="T_BAD", destination="I3", authorized=False)]
    cases.append(FaultCase("F05_unauthorized_transfer", "lifecycle", "semantic", clean, faulty, Query("EVER_EXPOSED", {"instance": "I3", "evidence": "E1", "system_time": 20}), False, ("T_BAD",)))

    clean = base_events() + [evidence()]
    faulty = copy.deepcopy(clean) + [transfer(tid="T_BAD", source="I3", destination="I2")]
    cases.append(FaultCase("F06_source_not_exposed", "lifecycle", "semantic", clean, faulty, Query("EVER_EXPOSED", {"instance": "I2", "evidence": "E1", "system_time": 20}), False, ("T_BAD",)))

    clean = base_events() + [evidence(), transfer(destination="I3", kind="evidence_copy")]
    faulty = copy.deepcopy(clean); next(e for e in faulty if e["id"] == "T1")["kind"] = "authorized_state_replication"
    cases.append(FaultCase("F07_identity_fork_replication", "lineage", "semantic", clean, faulty, Query("ATTRIBUTION", {"instance": "I3", "evidence": "E1", "system_time": 20}), "copied_artifact", ("T1",)))

    clean = base_events() + [evidence()]
    faulty = copy.deepcopy(clean) + [adoption(aid="A_BAD", destination="I3")]
    cases.append(FaultCase("F08_adoption_without_exposure", "lifecycle", "semantic", clean, faulty, Query("ATTITUDE", {"instance": "I3", "evidence": "E1", "system_time": 20}), "unknown", ("A_BAD",)))

    clean = base_events() + [
        evidence(eid="E_PRE", proposition="pre=true", valid=4, system=4),
        evidence(eid="E_POST", proposition="post=true", valid=14, system=14),
        {"id": "S1", "type": "snapshot", "source": "I1", "cutoff_system": 10, "entries": ["E_PRE"], "system_time": 15},
        {"id": "LR", "type": "lineage", "kind": "restore", "source": "I1", "destination": "I2", "authorized": True, "system_time": 20},
        {"id": "R1", "type": "restore", "snapshot": "S1", "destination": "I2", "valid_time": 20, "system_time": 20},
    ]
    faulty = copy.deepcopy(clean); next(e for e in faulty if e["id"] == "S1")["entries"].append("E_POST")
    cases.append(FaultCase("F09_snapshot_post_cutoff", "snapshot", "semantic", clean, faulty, Query("EVER_EXPOSED", {"instance": "I2", "evidence": "E_POST", "system_time": 30}), False, ("S1",)))

    clean = base_events() + [evidence(policy="private", allowed=("U",)), justification(), policy(pid="P_REVOKE")]
    faulty = copy.deepcopy(clean) + [policy(pid="Z_GRANT", operation="grant")]
    cases.append(FaultCase("F10_same_time_policy_conflict", "policy", "semantic", clean, faulty, Query("DISCLOSE", {"claim": "C1", "requester": "U", "system_time": 20}), False, ("P_REVOKE", "Z_GRANT")))

    clean = base_events() + [
        evidence(eid="E_PRIVATE", proposition="diagnosis=X", policy="private", allowed=("U",), origin="F_SECRET"),
        evidence(eid="E_SUMMARY", proposition="diagnosis=X", witnesses=(), policy="private", allowed=("U",), origin="F_SECRET", derived_from="E_PRIVATE", valid=6, system=6),
        justification(jid="J_SUMMARY", claim="C_DIAG", sources=("E_SUMMARY",), system=7),
    ]
    faulty = copy.deepcopy(clean); summary = next(e for e in faulty if e["id"] == "E_SUMMARY"); summary["policy"] = "public"; summary["allowed_requesters"] = []
    cases.append(FaultCase("F11_policy_laundering", "provenance_policy", "semantic", clean, faulty, Query("DISCLOSE", {"claim": "C_DIAG", "requester": "V", "system_time": 20}), False, ("E_SUMMARY",)))

    core = base_events() + [evidence(policy="private", allowed=("U",)), justification(), policy(pid="P_REVOKE")]
    clean = add_envelope(core, ["P_REVOKE"]); faulty = [copy.deepcopy(e) for e in clean if e["id"] != "P_REVOKE"]
    cases.append(FaultCase("F12_dropped_revoke_with_envelope", "omission", "envelope", clean, faulty, Query("DISCLOSE", {"claim": "C1", "requester": "U", "system_time": 20}), False, ("P_REVOKE",)))

    core = base_events() + [evidence(eid="E_POST", proposition="postfork=true", valid=15, system=15)]
    clean = add_envelope(core, ["B1"]); faulty = copy.deepcopy(clean); next(e for e in faulty if e["id"] == "B1")["fork_valid"] = 20
    cases.append(FaultCase("F13_fork_cutoff_tamper", "tamper", "envelope", clean, faulty, Query("WORLD", {"proposition": "postfork=true", "branch": "B1", "valid_time": 30, "system_time": 30}), None, ("B1",)))

    core = base_events() + [evidence(policy="private", allowed=("U",)), justification(), policy(pid="P_REVOKE")]
    clean = copy.deepcopy(core) + [{"id": "CACHE1", "type": "cache", "key": "disclose:C1:U", "value": False, "ledger_head_hash": ledger_head_hash(core), "system_time": 11}]
    faulty = copy.deepcopy(clean); cache = next(e for e in faulty if e["id"] == "CACHE1"); cache["value"] = True; cache["ledger_head_hash"] = "stale-head"
    cases.append(FaultCase("F14_stale_projection_cache", "projection_residue", "envelope", clean, faulty, Query("CACHE", {"key": "disclose:C1:U", "system_time": 20}), False, ("CACHE1",)))

    clean = core; faulty = [copy.deepcopy(e) for e in clean if e["id"] != "P_REVOKE"]
    cases.append(FaultCase("F15_dropped_revoke_no_envelope", "unobservable_omission", "unobservable", clean, faulty, Query("DISCLOSE", {"claim": "C1", "requester": "U", "system_time": 20}), False, ("P_REVOKE",), "No surviving record states that a revoke should exist."))

    clean = base_events() + [evidence(witnesses=("I1", "I2")), transfer(tid="T_REPORT", destination="I2", kind="attributed_report", valid=8, system=8)]
    cases.append(FaultCase("C01_direct_observation_dominates", "clean_control", "clean", clean, copy.deepcopy(clean), Query("ATTRIBUTION", {"instance": "I2", "evidence": "E1", "system_time": 20}), "direct_observation"))

    clean = base_events() + [evidence(), justification(), policy(pid="P_REVOKE", requester="U")]
    cases.append(FaultCase("C02_public_revoke_is_requester_specific", "clean_control", "clean", clean, copy.deepcopy(clean), Query("DISCLOSE", {"claim": "C1", "requester": "V", "system_time": 20}), True))
    return cases


REF_FIELDS = {"id", "parent", "source", "destination", "evidence", "snapshot", "about_branch", "derived_from", "claim"}
REF_LIST_FIELDS = {"witnesses", "entries", "sources", "expected_ids"}


def rename_case(case: FaultCase, seed: int) -> FaultCase:
    prefix = f"r{seed:02d}_"
    identifiers: set[str] = set(case.mutated_ids)
    for event in case.clean_events + case.faulty_events:
        for field in REF_FIELDS:
            if isinstance(event.get(field), str):
                identifiers.add(event[field])
        for field in REF_LIST_FIELDS:
            identifiers.update(x for x in event.get(field, []) if isinstance(x, str))
    for value in case.query.params.values():
        if isinstance(value, str) and value in identifiers:
            identifiers.add(value)
    mapping = {value: prefix + value for value in identifiers}

    def transform(events: list[dict[str, Any]], *, faulty: bool) -> list[dict[str, Any]]:
        result = copy.deepcopy(events)
        for event in result:
            for field in REF_FIELDS:
                if isinstance(event.get(field), str):
                    event[field] = mapping.get(event[field], event[field])
            for field in REF_LIST_FIELDS:
                if isinstance(event.get(field), list):
                    event[field] = [mapping.get(value, value) for value in event[field]]
            if event.get("type") == "envelope":
                event["hashes"] = {mapping.get(key, key): value for key, value in event.get("hashes", {}).items()}
        return result

    clean = transform(case.clean_events, faulty=False)
    faulty = transform(case.faulty_events, faulty=True)
    clean_by_id = {e.get("id"): e for e in clean}
    clean_envelopes = [e for e in clean if e.get("type") == "envelope"]
    for envelope in clean_envelopes:
        envelope["hashes"] = {event_id: event_hash(clean_by_id[event_id]) for event_id in envelope["expected_ids"]}
    clean_env_by_id = {e["id"]: e for e in clean_envelopes}
    for envelope in (e for e in faulty if e.get("type") == "envelope"):
        envelope["hashes"] = copy.deepcopy(clean_env_by_id[envelope["id"]]["hashes"])
    for event in clean:
        if event.get("type") == "cache":
            event["ledger_head_hash"] = ledger_head_hash(clean)
    for event in faulty:
        if event.get("type") == "cache" and case.case_id != "F14_stale_projection_cache":
            event["ledger_head_hash"] = ledger_head_hash(faulty)

    params = {key: mapping.get(value, value) if isinstance(value, str) else value for key, value in case.query.params.items()}
    return FaultCase(
        f"{case.case_id}__r{seed:02d}", case.fault_class, case.detectable_level,
        clean, faulty, Query(case.query.kind, params), case.expected,
        tuple(mapping.get(value, value) for value in case.mutated_ids), case.notes,
    )


def evaluate(case: FaultCase, system: SystemSpec) -> dict[str, Any]:
    start = time.perf_counter_ns()
    alerts = alerts_for_system(case.faulty_events, system)
    validate_ns = time.perf_counter_ns() - start
    is_clean = case.detectable_level == "clean"
    is_fault = not is_clean
    observable = case.detectable_level not in {"clean", "unobservable"}
    detected = bool(alerts)
    if detected:
        answer, query_ns, correct = "<quarantine>", 0, False
    else:
        start = time.perf_counter_ns()
        answer = resolve_query(case.faulty_events, case.query)
        query_ns = time.perf_counter_ns() - start
        correct = answer == case.expected
    mutated = set(case.mutated_ids)
    localized = detected and bool(mutated) and any(alert.event_id in mutated for alert in alerts)
    return {
        "case_id": case.case_id,
        "archetype_id": case.case_id.split("__")[0],
        "fault_class": case.fault_class,
        "detectable_level": case.detectable_level,
        "system": system.name,
        "representation": system.representation,
        "expected": json.dumps(case.expected, sort_keys=True),
        "answer": json.dumps(answer, sort_keys=True),
        "detected": int(detected),
        "observable_fault": int(observable),
        "fault": int(is_fault),
        "clean_control": int(is_clean),
        "correct_if_answered": int(correct),
        "uisr": int(is_fault and not detected and not correct),
        "accepted_invalid": int(is_fault and not detected),
        "false_alarm": int(is_clean and detected),
        "localized": int(localized),
        "alert_rules": "|".join(sorted({alert.rule for alert in alerts})),
        "alert_event_ids": "|".join(sorted({str(alert.event_id) for alert in alerts if alert.event_id is not None})),
        "validate_ns": validate_ns,
        "query_ns": query_ns,
    }


def mean(rows: list[dict[str, Any]], field: str) -> float:
    return sum(float(row[field]) for row in rows) / len(rows) if rows else 0.0


def quantile(values: list[float], q: float) -> float:
    values = sorted(values)
    if not values:
        return 0.0
    position = (len(values) - 1) * q
    lower = int(position)
    upper = min(lower + 1, len(values) - 1)
    fraction = position - lower
    return values[lower] * (1 - fraction) + values[upper] * fraction


def summarize(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    output = []
    for system in (spec.name for spec in SYSTEMS):
        group = [row for row in rows if row["system"] == system]
        observable = [row for row in group if row["observable_fault"]]
        faults = [row for row in group if row["fault"]]
        clean = [row for row in group if row["clean_control"]]
        detected = [row for row in observable if row["detected"]]
        timings = [row["validate_ns"] / 1000 for row in group]
        output.append({
            "system": system,
            "N_rows": len(group),
            "observable_fault_detection_recall": mean(observable, "detected"),
            "all_fault_detection_recall": mean(faults, "detected"),
            "UISR_all_faults": mean(faults, "uisr"),
            "UISR_observable_faults": mean(observable, "uisr"),
            "accepted_invalid_all_faults": mean(faults, "accepted_invalid"),
            "exact_localization_given_detection": mean(detected, "localized"),
            "clean_false_alarm_rate": mean(clean, "false_alarm"),
            "median_validate_us": statistics.median(timings),
            "p95_validate_us": quantile(timings, 0.95),
        })
    return sorted(output, key=lambda row: (-row["observable_fault_detection_recall"], row["UISR_all_faults"], row["system"]))


def detection_matrix(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    groups: dict[tuple[str, str, str, str], list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        groups[(row["archetype_id"], row["fault_class"], row["detectable_level"], row["system"])].append(row)
    output = []
    for (archetype, fault_class, level, system), group in sorted(groups.items()):
        output.append({
            "archetype_id": archetype,
            "fault_class": fault_class,
            "detectable_level": level,
            "system": system,
            "N": len(group),
            "DetectionRate": mean(group, "detected"),
            "UISR": mean(group, "uisr"),
            "FalseAlarmRate": mean(group, "false_alarm"),
            "ExactLocalizationRate": mean(group, "localized"),
            "AlertRules": "|".join(sorted({rule for row in group for rule in row["alert_rules"].split("|") if rule})),
        })
    return output


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        return
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)


def run(renamings: int, output_dir: Path) -> dict[str, Any]:
    base_cases = make_cases()
    for case in base_cases:
        clean_alerts = semantic_alerts(case.clean_events)
        if clean_alerts:
            raise AssertionError((case.case_id, [(a.rule, a.event_id) for a in clean_alerts]))
        actual = resolve_query(case.clean_events, case.query)
        if actual != case.expected:
            raise AssertionError((case.case_id, actual, case.expected))

    cases = [rename_case(case, seed) for seed in range(renamings) for case in base_cases]
    rows = [evaluate(case, system) for case in cases for system in SYSTEMS]
    summary = summarize(rows)
    matrix = detection_matrix(rows)

    pair_checks = {}
    for left, right in (("G-Complete", "T-Canonical"), ("G-Envelope", "T-Envelope")):
        left_rows = sorted((r for r in rows if r["system"] == left), key=lambda r: r["case_id"])
        right_rows = sorted((r for r in rows if r["system"] == right), key=lambda r: r["case_id"])
        fields = ("detected", "uisr", "accepted_invalid", "false_alarm", "localized", "alert_rules", "answer")
        identical = all([r[field] for r in left_rows] == [r[field] for r in right_rows] for field in fields)
        if not identical:
            raise AssertionError(f"equal-information pair diverged: {left} vs {right}")
        pair_checks[f"{left}__vs__{right}"] = {"rows": len(left_rows), "outcomes_identical": True}

    output_dir.mkdir(parents=True, exist_ok=True)
    write_csv(output_dir / "per_run.csv", rows)
    write_csv(output_dir / "summary.csv", summary)
    write_csv(output_dir / "detection_matrix.csv", matrix)
    metadata = {
        "suite": "MindMap-Track-E-Fault-Observability-v0.1",
        "scope": "fixed lifecycle fault-observability and validator-tier audit; not an end-to-end language or population-effect study",
        "base_archetypes": len(base_cases),
        "fault_archetypes": sum(case.detectable_level != "clean" for case in base_cases),
        "observable_fault_archetypes": sum(case.detectable_level not in {"clean", "unobservable"} for case in base_cases),
        "clean_control_archetypes": sum(case.detectable_level == "clean" for case in base_cases),
        "alpha_renamings": renamings,
        "evaluated_case_variants": len(cases),
        "system_count": len(SYSTEMS),
        "row_count": len(rows),
        "representation_pair_checks": pair_checks,
        "interpretation": [
            "Complete generic and typed systems share the same invariant specification and are expected to tie.",
            "Typed local constraints catch local/referential faults but not cross-event lifecycle faults.",
            "Semantic invariants cannot identify omissions or semantically valid tampering without an external commitment.",
            "Transaction envelopes and projection-head commitments catch the three committed omission/tamper/residue cases.",
            "A dropped revoke with no surviving command/envelope is intentionally unobservable from the remaining ledger.",
            "Wall-clock timings are Python/environment-specific exploratory measurements.",
        ],
        "no_population_inference": True,
        "python_version": platform.python_version(),
        "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    }
    (output_dir / "metadata.json").write_text(json.dumps(metadata, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return {"rows": rows, "summary": summary, "matrix": matrix, "metadata": metadata}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--renamings", type=int, default=20)
    parser.add_argument("--output-dir", type=Path, default=Path("results/track_e_fault_observability_v0_1"))
    args = parser.parse_args()
    report = run(args.renamings, args.output_dir)
    for row in report["summary"]:
        print(row)
    print(json.dumps(report["metadata"]["representation_pair_checks"], indent=2))
    print(f"Wrote results to {args.output_dir}")


if __name__ == "__main__":
    main()
